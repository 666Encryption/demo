# 666encryption


PS: Do you use $kype?
Please leave $ kype id here if you have. It would be better to get in touch via $ kype.

We are not allowed to chat out of freelancer chatbox so please don't say something about $kype there.
Thanks
